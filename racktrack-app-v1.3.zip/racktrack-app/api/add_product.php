<?php
include "config.php";

$data = json_decode(file_get_contents("php://input"), true);

$barcode = $data["productId"];
$sku = $data["sku"];
$supplier = $data["supplier"];
$product_name = $data["productName"];
$color = $data["color"];
$size = $data["size"];
$material = $data["material"];
$category_id = $data["category"];
$cost = $data["cost"];
$srp = $data["srp"];
$image_path = $data["imageData"] ?? null;
$status = "active";

$sql = "INSERT INTO products 
(barcode, sku, supplier, product_name, color, size, material, category_id, cost, srp, image_path, status)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

$stmt->bind_param(
  "sssssssidsss",
  $barcode,
  $sku,
  $supplier,
  $product_name,
  $color,
  $size,
  $material,
  $category_id,
  $cost,
  $srp,
  $image_path,
  $status
);

if ($stmt->execute()) {
  echo json_encode(["success" => true, "message" => "Product added successfully"]);
} else {
  echo json_encode(["success" => false, "message" => $stmt->error]);
}
?>