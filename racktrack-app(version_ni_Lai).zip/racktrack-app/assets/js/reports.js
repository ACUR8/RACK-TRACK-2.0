(function () {
  const {
    state,
    registerPanel,
    peso,
    removeDailyRecord,
    refreshAll
  } = window.RackTrack;

  function toNumber(value) {
    const num = Number(value);
    return Number.isFinite(num) ? num : 0;
  }

  function getSalesHistory() {
    const localSales = JSON.parse(
      localStorage.getItem(
        "racktrack_sales_history"
      )
    ) || [];

    if (localSales.length) {
      return localSales;
    }

    if (
      Array.isArray(state.salesHistory) &&
      state.salesHistory.length
    ) {
      return state.salesHistory;
    }

    if (
      Array.isArray(state.sales) &&
      state.sales.length
    ) {
      return state.sales;
    }

    return [];
  }

  /* ==========================
     PIE CHART
  ========================== */

  function renderFinancialPieChart({
    revenue,
    cogs,
    inventoryInvestment,
    profit
  }) {

    const canvas =
      document.getElementById(
        "financialPieChart"
      );

    if (!canvas) return;

    // destroy old chart
    if (
      window.financialPieChartInstance
    ) {
      window.financialPieChartInstance.destroy();
    }

    window.financialPieChartInstance =
      new Chart(canvas, {
        type: "doughnut",

        data: {
          labels: [
            "Revenue",
            "COGS",
            "Investment",
            "Profit"
          ],

          datasets: [{
            data: [
              revenue,
              cogs,
              inventoryInvestment,
              profit
            ],

            backgroundColor: [
              "#6BBF8A",
              "#F28C8C",
              "#89A7FF",
              "#D3B27A"
            ],

            borderWidth: 0
          }]
        },

        options: {
          responsive: true,
          maintainAspectRatio: false,

          cutout: "68%",

          plugins: {
            legend: {
              position: "bottom",

              labels: {
                usePointStyle: true,
                pointStyle: "circle",
                padding: 20
              }
            }
          }
        }
      });
  }

  /* ==========================
     FINANCIAL CARDS
  ========================== */

  function renderFinancialCards() {

    const sales =
      getSalesHistory();

    let revenue = 0;
    let cogs = 0;
    let profit = 0;
    let inventoryInvestment = 0;

    // SALES
    sales.forEach(sale => {

      const qty =
        toNumber(sale.quantity) ||
        toNumber(sale.quantitySold) ||
        0;

      const saleRevenue =
        toNumber(sale.saleAmount) ||
        toNumber(
          sale.totalRevenue
        ) ||
        0;

      const saleProfit =
        toNumber(
          sale.profitAmount
        ) ||
        toNumber(
          sale.totalProfit
        ) ||
        0;

      const saleCost =
        toNumber(sale.cost) *
        qty;

      revenue += saleRevenue;
      cogs += saleCost;
      profit += saleProfit;
    });

    // INVENTORY INVESTMENT
    const inventory =
      Array.isArray(
        state.inventory
      )
        ? state.inventory
        : [];

    inventory.forEach(item => {

      const qty =
        toNumber(item.quantity) ||
        toNumber(item.newQty) ||
        0;

      const cost =
        toNumber(item.cost);

      inventoryInvestment +=
        qty * cost;
    });

    // UPDATE UI
    document.getElementById(
      "reportRevenue"
    ).textContent =
      peso(revenue);

    document.getElementById(
      "reportCOGS"
    ).textContent =
      peso(cogs);

    document.getElementById(
      "reportInventoryInvestment"
    ).textContent =
      peso(
        inventoryInvestment
      );

    document.getElementById(
      "reportProfit"
    ).textContent =
      peso(profit);

    // CHART
    renderFinancialPieChart({
      revenue,
      cogs,
      inventoryInvestment,
      profit
    });
  }

  /* ==========================
     PERIOD REPORTS
  ========================== */

  function renderPeriodReport(
    containerId,
    filterFn
  ) {

    const sales =
      getSalesHistory();

    const filteredSales =
      sales.filter(filterFn);

    let revenue = 0;
    let profit = 0;
    let transactions =
      new Set();
    let itemsSold = 0;

    filteredSales.forEach(
      sale => {

        revenue +=
          toNumber(
            sale.saleAmount
          ) ||
          toNumber(
            sale.totalRevenue
          ) ||
          0;

        profit +=
          toNumber(
            sale.profitAmount
          ) ||
          toNumber(
            sale.totalProfit
          ) ||
          0;

        transactions.add(
          sale
            .completedTransactionId ||
          sale.transactionId
        );

        itemsSold +=
          toNumber(
            sale.quantity
          ) ||
          toNumber(
            sale.quantitySold
          ) ||
          0;
      }
    );

    const container =
      document.getElementById(
        containerId
      );

    if (!container) return;

    if (
      !filteredSales.length
    ) {
      container.innerHTML =
        `<div class="empty-state">
          No data yet.
        </div>`;
      return;
    }

    container.innerHTML = `
      <div class="period-report-content">

        <div class="period-report-row">
          <span>Revenue</span>
          <strong>${peso(revenue)}</strong>
        </div>

        <div class="period-report-row">
          <span>Profit</span>
          <strong>${peso(profit)}</strong>
        </div>

        <div class="period-report-row">
          <span>Transactions</span>
          <strong>${transactions.size}</strong>
        </div>

        <div class="period-report-row">
          <span>Items Sold</span>
          <strong>${itemsSold}</strong>
        </div>

      </div>
    `;
  }

  function renderDailyReport() {

    const today =
      new Date();

    // DAILY
    renderPeriodReport(
      "dailyReportCard",
      sale => {
        const d =
          new Date(
            sale.createdAt ||
            sale.soldAt
          );

        return (
          d.toDateString() ===
          today.toDateString()
        );
      }
    );

    // WEEKLY
    renderPeriodReport(
      "weeklyReportCard",
      sale => {

        const d =
          new Date(
            sale.createdAt ||
            sale.soldAt
          );

        const start =
          new Date(today);

        start.setDate(
          today.getDate() -
          today.getDay()
        );

        start.setHours(
          0,0,0,0
        );

        const end =
          new Date(start);

        end.setDate(
          start.getDate() + 6
        );

        end.setHours(
          23,59,59,999
        );

        return (
          d >= start &&
          d <= end
        );
      }
    );

    // MONTHLY
    renderPeriodReport(
      "monthlyReportCard",
      sale => {

        const d =
          new Date(
            sale.createdAt ||
            sale.soldAt
          );

        return (
          d.getMonth() ===
            today.getMonth() &&
          d.getFullYear() ===
            today.getFullYear()
        );
      }
    );

    // YEARLY
    renderPeriodReport(
      "yearlyReportCard",
      sale => {

        const d =
          new Date(
            sale.createdAt ||
            sale.soldAt
          );

        return (
          d.getFullYear() ===
          today.getFullYear()
        );
      }
    );
  }

  function render() {
    renderFinancialCards();
    renderDailyReport();
  }

  registerPanel({
    name: "reports",
    render
  });

  window.RackTrackReportsPanel = {
    render
  };

})();