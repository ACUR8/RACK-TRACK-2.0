<?php
include "config.php";

$sql = "
SELECT 
    i.inventory_id as id,
    i.product_id as productId,
    p.product_id as sourceProductId,
    p.barcode,
    p.sku,
    p.product_name as productName,
    p.color,
    p.size,
    p.material,
    p.supplier,
    p.category_id as categoryId,
    c.category_name as category,
    c.category_color,
    i.quantity,
    p.cost,
    p.srp,
    i.low_stock_threshold as lowStockThreshold,
    p.image_path as imageData,
    p.status,
    i.created_at as createdAt,
    i.updated_at as updatedAt
FROM inventory i
LEFT JOIN products p ON i.product_id = p.product_id
LEFT JOIN categories c ON p.category_id = c.category_id
ORDER BY i.created_at DESC
";

$result = $conn->query($sql);

if (!$result) {
    die(json_encode(["error" => $conn->error]));
}

$inventory = [];

while ($row = $result->fetch_assoc()) {
    $inventory[] = $row;
}

header("Content-Type: application/json");
echo json_encode($inventory);
?>
