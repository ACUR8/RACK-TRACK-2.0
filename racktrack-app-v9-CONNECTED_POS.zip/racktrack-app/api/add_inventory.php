<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include "config.php";

$product_id = $_POST["product_id"] ?? null;
$quantity = (int)($_POST["quantity"] ?? 0);
$low_stock_threshold = (int)($_POST["low_stock_threshold"] ?? 5);

if (!$product_id || $quantity < 0) {
    echo json_encode(["success" => false, "message" => "Invalid product_id or quantity"]);
    exit;
}

// Verify product exists
$verify_sql = "SELECT product_id FROM products WHERE product_id = ?";
$verify_stmt = $conn->prepare($verify_sql);
$verify_stmt->bind_param("s", $product_id);
$verify_stmt->execute();
$verify_result = $verify_stmt->get_result();

if ($verify_result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Product not found"]);
    exit;
}

// Insert into inventory
$sql = "INSERT INTO inventory (product_id, quantity, low_stock_threshold) 
        VALUES (?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sii", $product_id, $quantity, $low_stock_threshold);

if ($stmt->execute()) {
    $inventory_id = $conn->insert_id;
    
    // Fetch the newly created record with product details
    $fetch_sql = "
    SELECT 
        i.inventory_id as id,
        i.product_id as productId,
        p.product_id as sourceProductId,
        p.barcode,
        p.sku,
        p.product_name as productName,
        p.color,
        p.size,
        p.material,
        p.supplier,
        p.category_id as categoryId,
        c.category_name as category,
        c.category_color,
        i.quantity,
        p.cost,
        p.srp,
        i.low_stock_threshold as lowStockThreshold,
        p.image_path as imageData,
        p.status
    FROM inventory i
    LEFT JOIN products p ON i.product_id = p.product_id
    LEFT JOIN categories c ON p.category_id = c.category_id
    WHERE i.inventory_id = ?
    ";
    
    $fetch_stmt = $conn->prepare($fetch_sql);
    $fetch_stmt->bind_param("i", $inventory_id);
    $fetch_stmt->execute();
    $result = $fetch_stmt->get_result();
    $newRecord = $result->fetch_assoc();
    
    echo json_encode([
        "success" => true, 
        "message" => "Inventory item added successfully",
        "data" => $newRecord
    ]);
} else {
    echo json_encode(["success" => false, "message" => $stmt->error]);
}
?>
