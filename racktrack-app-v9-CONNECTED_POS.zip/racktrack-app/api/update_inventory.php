<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include "config.php";

$inventory_id = (int)($_POST["inventory_id"] ?? 0);
$product_id = $_POST["product_id"] ?? null;
$new_quantity = (int)($_POST["new_quantity"] ?? 0);

if (!$inventory_id || !$product_id || $new_quantity < 0) {
    echo json_encode(["success" => false, "message" => "Invalid inventory_id, product_id, or new_quantity"]);
    exit;
}

// Verify inventory exists and belongs to this product
$verify_sql = "SELECT inventory_id FROM inventory WHERE inventory_id = ? AND product_id = ?";
$verify_stmt = $conn->prepare($verify_sql);
$verify_stmt->bind_param("is", $inventory_id, $product_id);
$verify_stmt->execute();
$verify_result = $verify_stmt->get_result();

if ($verify_result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Inventory record not found"]);
    exit;
}

// Update inventory quantity
$sql = "UPDATE inventory SET quantity = ? WHERE inventory_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $new_quantity, $inventory_id);

if ($stmt->execute()) {
    // Fetch the updated record with product details
    $fetch_sql = "
    SELECT 
        i.inventory_id as id,
        i.product_id as productId,
        p.product_id as sourceProductId,
        p.barcode,
        p.sku,
        p.product_name as productName,
        p.color,
        p.size,
        p.material,
        p.supplier,
        p.category_id as categoryId,
        c.category_name as category,
        c.category_color,
        i.quantity,
        p.cost,
        p.srp,
        i.low_stock_threshold as lowStockThreshold,
        p.image_path as imageData,
        p.status
    FROM inventory i
    LEFT JOIN products p ON i.product_id = p.product_id
    LEFT JOIN categories c ON p.category_id = c.category_id
    WHERE i.inventory_id = ?
    ";
    
    $fetch_stmt = $conn->prepare($fetch_sql);
    $fetch_stmt->bind_param("i", $inventory_id);
    $fetch_stmt->execute();
    $result = $fetch_stmt->get_result();
    $updatedRecord = $result->fetch_assoc();
    
    echo json_encode([
        "success" => true, 
        "message" => "Inventory updated successfully",
        "data" => $updatedRecord
    ]);
} else {
    echo json_encode(["success" => false, "message" => $stmt->error]);
}
?>
