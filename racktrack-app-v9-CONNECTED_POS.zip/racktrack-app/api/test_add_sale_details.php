﻿<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h2>Testing add_sale_details.php</h2>";

$ch = curl_init();

$data = [
    "sale_id"     => 2,
    "product_id"  => 2,
    "quantity"    => 1,
    "cost"        => 250,
    "srp"         => 499,
    "line_total"  => 499,
    "line_profit" => 249
];

curl_setopt_array($ch, [
    CURLOPT_URL => "http://localhost/racktrack-app/api/add_sale_details.php",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $data
]);

$response = curl_exec($ch);

echo "<h3>Raw Response:</h3>";
echo "<pre>";
var_dump($response);
echo "</pre>";

$response = preg_replace('/^\xEF\xBB\xBF/', '', $response);

echo "<h3>Decoded JSON:</h3>";
echo "<pre>";
print_r(json_decode($response, true));
echo "</pre>";

if (curl_errno($ch)) {
    echo "<h3>cURL Error:</h3>";
    echo curl_error($ch);
}

curl_close($ch);
