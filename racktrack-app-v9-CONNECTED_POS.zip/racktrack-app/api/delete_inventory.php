<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include "config.php";

$inventory_id = (int)($_POST["inventory_id"] ?? 0);

if (!$inventory_id) {
    echo json_encode(["success" => false, "message" => "Invalid inventory_id"]);
    exit;
}

// Verify inventory exists
$verify_sql = "SELECT inventory_id FROM inventory WHERE inventory_id = ?";
$verify_stmt = $conn->prepare($verify_sql);
$verify_stmt->bind_param("i", $inventory_id);
$verify_stmt->execute();
$verify_result = $verify_stmt->get_result();

if ($verify_result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Inventory record not found"]);
    exit;
}

// Delete inventory record
$sql = "DELETE FROM inventory WHERE inventory_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $inventory_id);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true, 
        "message" => "Inventory item deleted successfully"
    ]);
} else {
    echo json_encode(["success" => false, "message" => $stmt->error]);
}
?>
