<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include "config.php";

// Extract POST parameters
$product_id = (int)($_POST["product_id"] ?? 0);
$movement_type = $_POST["movement_type"] ?? "";
$quantity_before = (int)($_POST["quantity_before"] ?? 0);
$quantity_change = (int)($_POST["quantity_change"] ?? 0);
$quantity_after = (int)($_POST["quantity_after"] ?? 0);
$note = trim($_POST["note"] ?? "");
$reference_type = $_POST["reference_type"] ?? "manual";

$reference_id = isset($_POST["reference_id"]) && $_POST["reference_id"] !== ""
    ? (int)$_POST["reference_id"]
    : null;

$created_by = 1;

// Validate required fields
if (
    !$product_id ||
    !$movement_type ||
    $quantity_before < 0 ||
    $quantity_after < 0
) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid product_id, movement_type, or quantity values"
    ]);
    exit;
}

// Verify product exists
$verify_sql = "SELECT product_id FROM products WHERE product_id = ?";
$verify_stmt = $conn->prepare($verify_sql);
$verify_stmt->bind_param("i", $product_id);
$verify_stmt->execute();
$verify_result = $verify_stmt->get_result();

if ($verify_result->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "Product not found"
    ]);
    exit;
}

// Insert stock movement
$sql = "INSERT INTO stock_movements (
    product_id,
    movement_type,
    quantity_before,
    quantity_change,
    note,
    quantity_after,
    reference_type,
    reference_id,
    created_by
)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Prepare failed: " . $conn->error
    ]);
    exit;
}

$stmt->bind_param(
    "isiisisii",
    $product_id,
    $movement_type,
    $quantity_before,
    $quantity_change,
    $note,
    $quantity_after,
    $reference_type,
    $reference_id,
    $created_by
);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Stock movement saved successfully"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to save stock movement: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

?>