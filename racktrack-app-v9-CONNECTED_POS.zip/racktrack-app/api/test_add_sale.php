<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h2>Testing add_sale.php</h2>";

$ch = curl_init();

$data = [
    "receipt_no" => "TEST-" . time(),
    "subtotal" => 2500,
    "discount" => 0,
    "total" => 2500,
    "amount_paid" => 2500,
    "change_amount" => 0,
    "note" => "Manual API test"
];

curl_setopt_array($ch, [
    CURLOPT_URL => "http://localhost/racktrack-app/api/add_sale.php",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $data
]);

$response = curl_exec($ch);

echo "<h3>Raw Response:</h3>";
echo "<pre>";
var_dump($response);
echo "</pre>";

echo "<h3>Decoded JSON:</h3>";
echo "<pre>";
print_r(json_decode($response, true));
echo "</pre>";

if (curl_errno($ch)) {
    echo "<h3>cURL Error:</h3>";
    echo curl_error($ch);
}

curl_close($ch);