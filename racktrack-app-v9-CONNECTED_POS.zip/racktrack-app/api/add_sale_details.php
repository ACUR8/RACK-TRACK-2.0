﻿<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include "config.php";

// Extract POST parameters
$sale_id     = isset($_POST["sale_id"]) && $_POST["sale_id"] !== ""
    ? (int)$_POST["sale_id"]
    : null;
$product_id  = isset($_POST["product_id"]) && $_POST["product_id"] !== ""
    ? (int)$_POST["product_id"]
    : null;
$quantity    = (int)($_POST["quantity"] ?? 0);
$cost        = (float)($_POST["cost"] ?? 0);
$srp         = (float)($_POST["srp"] ?? 0);
$line_total  = (float)($_POST["line_total"] ?? 0);
$line_profit = (float)($_POST["line_profit"] ?? 0);

// Validate required fields
if (
    !$sale_id ||
    !$product_id ||
    $quantity <= 0 ||
    !is_numeric($cost) ||
    !is_numeric($srp) ||
    !is_numeric($line_total) ||
    !is_numeric($line_profit)
) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid sale_id, product_id, quantity, cost, srp, line_total, or line_profit"
    ]);
    exit;
}

// Verify sale exists
$verify_sale_sql = "SELECT sale_id FROM sales WHERE sale_id = ?";
$verify_sale_stmt = $conn->prepare($verify_sale_sql);
$verify_sale_stmt->bind_param("i", $sale_id);
$verify_sale_stmt->execute();
$verify_sale_result = $verify_sale_stmt->get_result();

if ($verify_sale_result->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "Sale not found"
    ]);
    exit;
}

// Verify product exists
$verify_product_sql = "SELECT product_id FROM products WHERE product_id = ?";
$verify_product_stmt = $conn->prepare($verify_product_sql);
$verify_product_stmt->bind_param("i", $product_id);
$verify_product_stmt->execute();
$verify_product_result = $verify_product_stmt->get_result();

if ($verify_product_result->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "Product not found"
    ]);
    exit;
}

// Insert sale detail
$sql = "INSERT INTO sale_details (
    sale_id,
    product_id,
    quantity,
    cost,
    srp,
    line_total,
    line_profit
) VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Prepare failed: " . $conn->error
    ]);
    exit;
}

$stmt->bind_param(
    "iiddddd",
    $sale_id,
    $product_id,
    $quantity,
    $cost,
    $srp,
    $line_total,
    $line_profit
);

if ($stmt->execute()) {
    echo json_encode([
        "success"         => true,
        "message"         => "Sale detail added successfully",
        "sale_details_id" => $conn->insert_id
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to save sale detail: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

?>
