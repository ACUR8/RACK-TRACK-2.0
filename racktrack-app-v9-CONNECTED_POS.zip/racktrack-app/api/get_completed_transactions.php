<?php
header('Content-Type: application/json');

require_once 'config.php';

try {

    $query = "
        SELECT
                CONCAT(
                'CT-',
                DATE_FORMAT(s.sale_date, '%Y%m%d'),
                '-',
                LPAD(s.sale_id, 6, '0')
            ) AS completedTransactionId,
            s.sale_id,
            s.receipt_no AS receiptNo,
            sd.product_id AS productId,
            p.product_name AS productName,
            p.sku AS sku,
            sd.quantity AS quantity,
            sd.srp AS srp,
            sd.cost AS cost,
            s.sale_date AS createdAt,
            'Walk-in Customer' AS customerName,
            '' AS customerContact,
            '' AS customerAddress,
            COALESCE(c.category_name, 'Uncategorized') AS category,
            sd.line_total AS totalRevenue,
            sd.line_profit AS totalProfit,
            'Completed' AS status,
            sd.product_id AS inventoryId
        FROM sales s
        INNER JOIN sale_details sd 
            ON s.sale_id = sd.sale_id
        INNER JOIN products p 
            ON sd.product_id = p.product_id
        LEFT JOIN categories c 
            ON p.category_id = c.category_id
        WHERE s.sale_status = 'completed'
        ORDER BY s.sale_date DESC
    ";

    $result = $conn->query($query);

    if (!$result) {
        throw new Exception($conn->error);
    }

    $transactions = [];

    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }

    echo json_encode([
        'success' => true,
        'transactions' => $transactions
    ]);

} catch (Exception $e) {

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>