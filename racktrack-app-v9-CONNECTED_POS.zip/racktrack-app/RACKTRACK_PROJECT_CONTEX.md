# RackTrack Project Context

## Overview

RackTrack is an inventory and POS management system for clothing businesses.

Purpose:
- Inventory management
- Point-of-sale transactions
- Stock movement tracking
- Revenue and profit reporting
- Role-based system access

Modules:
- Login
- Dashboard
- Inventory
- POS
- Reports
- Settings

---

## Authentication

Login Module Files:
- pages/admin-login.html
- pages/staff-login.html
- pages/forgot-password.html
- pages/role.html

Purpose:
- Role-based authentication
- Admin and staff access
- Login validation
- Session/localStorage authentication flow

---

## Tech Stack

Frontend:
- HTML
- CSS
- Vanilla JavaScript

Backend:
- PHP API

Database:
- MySQL (phpMyAdmin)

Environment:
- XAMPP localhost

Architecture:
- Frontend-heavy state
- localStorage + DB sync
- Modular JavaScript

---

## Important Files

### Core

assets/js/dashboard-core.js
Responsibilities:
- Global state
- localStorage persistence
- Shared utilities
- App hydration
- Global storage keys

assets/js/dashboard.js
Responsibilities:
- Dashboard navigation
- Section switching
- Main app rendering

---

### Inventory Module

assets/js/dashboard-panel-inventory.js
Responsibilities:
- Inventory CRUD
- Product stock rendering
- Category filtering
- Inventory item management
- Product management

API:
- api/get_inventory.php
- api/update_inventory.php
- api/add_inventory.php
- api/delete_inventory.php

---

### POS Module

assets/js/dashboard-panel-pos.js
Responsibilities:
- POS logic
- Cart system
- Checkout flow
- Receipt generation
- Completed transactions
- Confirmation modal
- Transaction details modal
- Inventory deduction sync

API:
- api/add_sale.php
- api/add_sale_details.php
- api/get_completed_transactions.php
- api/update_inventory.php
- api/add_stock_movement.php

---

### Reports Module

assets/js/dashboard-panel-reports.js
Responsibilities:
- Revenue reports
- Profit reports
- Financial overview
- Inventory movement analytics
- Sales analytics

API:
- api/get_stock_movements.php

---

### Dashboard Module

assets/js/dashboard-panel-dashboard.js
Responsibilities:
- Dashboard overview
- KPI rendering
- Summary cards

---

## Database

Database:
- MySQL (phpMyAdmin)

Important Tables:
- users
- products
- inventory
- categories
- sales
- sale_details
- stock_movements

Important Notes:
- `inventory.quantity` is the live stock source of truth
- `sales.sale_status` supports:
  - completed
  - voided
  - refunded
- `sale_details` stores sold item breakdown
- `stock_movements` stores inventory movement history

---

## Architecture Notes

RackTrack uses a hybrid architecture.

Frontend:
- UI state handled in JavaScript
- localStorage used for persistence
- Cart state stored client-side
- Fast UI rendering

Backend:
- PHP APIs communicate with MySQL
- Database acts as source of truth

Important:
- Inventory updates must persist to database
- UI refresh must preserve DB state
- Avoid frontend-only fake updates
- localStorage should sync with database state
- Hard refresh must not break inventory consistency

---

## State Management

Global State Location:
assets/js/dashboard-core.js

Current State Includes:
- categories
- products
- inventory
- orders
- customers
- stockHistory
- sales
- salesHistory
- voidedItems
- posCart

Important:
- `posCart` is dynamically initialized in:
  assets/js/dashboard-panel-pos.js

- `voidedItems` is stored in global state

Persistence:
- localStorage + database synchronization

---

## Development Rules

Always:
- Make minimal edits only
- Preserve working functionality
- Explain exact files changed
- Keep code style consistent
- Follow existing naming conventions
- Prefer patching existing functions over rewriting
- Scan the entire file before editing
- Identify dependencies before changes

Never:
- Refactor unrelated working code
- Rename variables unnecessarily
- Rewrite whole files
- Change architecture without approval
- Add frameworks/libraries
- Replace working logic unless required

Before Editing:
1. Scan the whole file first
2. Identify dependencies
3. Explain risks before major edits
4. Edit only the minimum required lines
5. Preserve working functionality

---

## Current Progress

Completed:
✓ Login module
✓ Inventory CRUD
✓ POS checkout
✓ Completed transactions
✓ Inventory movement history
✓ Database inventory deduction
✓ Persistent inventory after refresh
✓ Multi-item checkout
✓ Stock validation
✓ Out-of-stock prevention
✓ Hidden zero-stock items in POS
✓ Receipt generation
✓ Sales details modal
✓ Inventory sync after checkout

Current Phase:
POS voided items workflow

---

## Professor Requirement (High Priority)

POS Voided Item Workflow:

Requirements:
- Minus button creates voided item
- Remove button creates voided item
- Voided stock does NOT return immediately
- Inventory should only return voided stock AFTER checkout confirmation
- Checkout confirmation modal must display:
  - Sold items
  - Voided items
  - Quantity
  - Pricing breakdown
  - Totals

After Checkout Confirmation:
- Receipt should display successfully
- Inventory history must show:
  - Sold items
  - Voided items
- Completed transactions must show:
  - Sold items
  - Voided items
  - Sales details
  - Pricing breakdown

Important Behavior:
Example:
1. User adds quantity 2
2. User clicks minus
3. Cart becomes quantity 1
4. Remaining quantity 1 becomes "voided item"
5. Inventory is NOT restored yet
6. Checkout confirmation modal shows:
   - 1 sold item
   - 1 voided item
7. User confirms checkout
8. Sold item deducts from inventory
9. Voided item returns to stock
10. History + completed transaction records update

---

## Current Priority

Do NOT redesign UI unless requested.

Focus only on:
1. Functionality
2. Database persistence
3. POS voided item workflow
4. Maintaining existing working systems

UI changes should be minimal and preserve teammate work.

---

## Coding Style

Preferred:
- Minimal patch edits
- Existing code patterns
- Existing naming conventions
- Reuse helper functions

Avoid:
- Overengineering
- Large rewrites
- Unnecessary abstractions
- Breaking working logic

Project Type:
Student capstone/thesis project

Priority:
Stability > Refactoring