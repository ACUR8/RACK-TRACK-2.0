﻿(function () {
  const {
    state,
    registerPanel,
    renderImageCell,
    renderCategoryBadge,
    peso,
    escapeHtml,
    addSaleRecord,
    addStockHistoryEntry,
    saveData,
    refreshAll
  } = window.RackTrack || {};

  if (!state) {
    console.warn("RackTrack state is not available.");
    return;
  }

  const LOW_STOCK_THRESHOLD = 5;
  const COMPLETED_ROWS_PER_PAGE = 10;
  const ACTIVE_SECTION_KEY = "racktrack_active_section";

  const STORAGE_KEYS = {
    sales: "racktrack_sales",
    salesHistory: "racktrack_sales_history",
    inventory: "racktrack_inventory",
    stockHistory: "racktrack_stock_history",
    posDocuments: "racktrack_pos_documents",
    posCart: "racktrack_pos_cart",
    posActiveView: "racktrack_pos_active_view",
    posSelectedTransaction: "racktrack_pos_selected_transaction"
  };

  const posFilters = {
    search: "",
    category: "all",
    date: "",
    latestOnly: true
  };

  const shopFilters = {
    search: "",
    category: "all"
  };

  const tablePagerState = {
    completedTransactions: {
      page: 1,
      pageSize: COMPLETED_ROWS_PER_PAGE
    }
  };

  const BARCODE_SCAN = {
    enabled: true,
    buffer: "",
    lastTime: 0,
    timeoutMs: 120,
    minLength: 3
  };

  function html(value) {
    return typeof escapeHtml === "function"
      ? escapeHtml(String(value ?? ""))
      : String(value ?? "")
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#39;");
  }

  function formatPeso(value) {
    return typeof peso === "function"
      ? peso(Number(value) || 0)
      : `â‚±${(Number(value) || 0).toFixed(2)}`;
  }

  function normalizeText(value) {
    return String(value || "").trim().toLowerCase();
  }

  function normalizeCode(value) {
    return String(value || "").trim().toLowerCase().replace(/\s+/g, "");
  }

  function normalizePHPhone(value) {
    let digits = String(value || "").replace(/\D/g, "");

    if (digits.startsWith("63")) digits = digits.slice(2);
    if (digits.startsWith("0")) digits = digits.slice(1);

    digits = digits.slice(0, 10);

    if (!digits) return "";
    if (!digits.startsWith("9")) return "";

    const part1 = digits.slice(0, 3);
    const part2 = digits.slice(3, 6);
    const part3 = digits.slice(6, 10);

    return `+63 ${part1}${part2 ? " " + part2 : ""}${part3 ? " " + part3 : ""}`.trim();
  }

  function isValidPHPhone(value) {
    return /^\+63 9\d{2} \d{3} \d{4}$/.test(String(value || "").trim());
  }

  function safeValue(value, fallback = "-") {
    const text = String(value ?? "").trim();
    return text || fallback;
  }

  function createId(prefix) {
    const stamp = Date.now();
    const rand = Math.floor(Math.random() * 100000);
    return `${prefix}-${stamp}-${rand}`;
  }

  function pad2(value) {
    return String(value).padStart(2, "0");
  }

  function pad3(value) {
    return String(value).padStart(3, "0");
  }

  function generateCompletedTransactionId() {
    const now = new Date();

    const datePart = [
      now.getFullYear(),
      pad2(now.getMonth() + 1),
      pad2(now.getDate())
    ].join("");

    const timePart = [
      pad2(now.getHours()),
      pad2(now.getMinutes()),
      pad2(now.getSeconds())
    ].join("");

    const randomPart = pad3(Math.floor(Math.random() * 1000));

    return `CT-${datePart}-${timePart}-${randomPart}`;
  }

  function getNowISO() {
    return new Date().toISOString();
  }

  function formatDateTime(value) {
    if (!value) return "-";

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "-";

    return date.toLocaleString("en-US", {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  function getDateOnly(value) {
    if (!value) return "";

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";

    return [
      date.getFullYear(),
      pad2(date.getMonth() + 1),
      pad2(date.getDate())
    ].join("-");
  }

  function safeParseArray(rawValue) {
    try {
      const parsed = JSON.parse(rawValue);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      return [];
    }
  }

  function safeParseObject(rawValue) {
    try {
      const parsed = JSON.parse(rawValue);
      return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : null;
    } catch (error) {
      return null;
    }
  }

  function getSaleDedupeKey(record = {}) {
    const tx = String(
      record.completedTransactionId ||
      record.transactionId ||
      record.completedSaleId ||
      record.saleGroupId ||
      ""
    ).trim();

    const item = String(
      record.inventoryId ||
      record.itemId ||
      record.productId ||
      record.sku ||
      record.productName ||
      record.name ||
      ""
    ).trim();

    const createdAt = String(record.createdAt || record.soldAt || "").trim();

    if (tx && item) return `sale:${tx}:${item}`;
    if (tx && createdAt) return `sale:${tx}:${createdAt}`;

    return "";
  }

  function dedupeRecords(records) {
    const map = new Map();

    records.forEach(record => {
      if (!record || typeof record !== "object") return;

      const saleKey = getSaleDedupeKey(record);

      const key = String(
        saleKey ||
          record.id ||
          record.receiptNo ||
          record.invoiceNo ||
          `${record.productId || record.sku || record.productName || "unknown"}__${
            record.createdAt || record.soldAt || Date.now()
          }`
      );

      if (!map.has(key)) {
        map.set(key, record);
        return;
      }

      const existing = map.get(key);

      map.set(key, {
        ...record,
        ...existing,
        id: existing.id || record.id,
        imageData: existing.imageData || record.imageData || record.image || "",
        image: existing.image || record.image || record.imageData || "",
        createdAt: existing.createdAt || record.createdAt,
        soldAt: existing.soldAt || record.soldAt
      });
    });

    return Array.from(map.values());
  }

  function getStockHistoryRecords() {
    const memoryStockHistory = Array.isArray(state.stockHistory) ? state.stockHistory : [];
    const storageStockHistory = safeParseArray(localStorage.getItem(STORAGE_KEYS.stockHistory));

    const merged = dedupeRecords([
      ...memoryStockHistory,
      ...storageStockHistory
    ]).sort((a, b) => {
      const aTime = new Date(a.createdAt || 0).getTime();
      const bTime = new Date(b.createdAt || 0).getTime();
      return bTime - aTime;
    });

    state.stockHistory = merged.slice();

    try {
      localStorage.setItem(STORAGE_KEYS.stockHistory, JSON.stringify(merged));
    } catch (error) {
      console.warn("Unable to persist stock history state:", error);
    }

    return merged;
  }

  function isSoldMovement(entry = {}) {
    const movementType = normalizeText(
      entry.movementType ||
        entry.type ||
        entry.action ||
        entry.status
    );

    return movementType === "sold" || movementType === "sale";
  }

  function createRecoveredSaleId(entry = {}) {
    return String(
      entry.id ||
        `recovered-sale-${entry.completedTransactionId || entry.transactionId || "no-tx"}-${
          entry.inventoryId || entry.itemId || entry.productId || entry.sku || "no-item"
        }-${entry.createdAt || Date.now()}-${entry.quantity || entry.quantitySold || entry.sold || 0}`
    );
  }

  function setLastActiveSection(sectionId = "pos-section") {
    try {
      localStorage.setItem(ACTIVE_SECTION_KEY, sectionId);
    } catch (error) {
      console.warn("Unable to persist active section:", error);
    }
  }

  function persistSalesState() {
    try {
      localStorage.setItem(
        STORAGE_KEYS.sales,
        JSON.stringify(Array.isArray(state.sales) ? state.sales : [])
      );

      localStorage.setItem(
        STORAGE_KEYS.salesHistory,
        JSON.stringify(Array.isArray(state.salesHistory) ? state.salesHistory : [])
      );
    } catch (error) {
      console.warn("Unable to persist sales state:", error);
    }
  }

  function persistPosState() {
    try {
      localStorage.setItem(
        STORAGE_KEYS.posDocuments,
        JSON.stringify(Array.isArray(state.posDocuments) ? state.posDocuments : [])
      );

      localStorage.setItem(
        STORAGE_KEYS.posCart,
        JSON.stringify(Array.isArray(state.posCart) ? state.posCart : [])
      );

      localStorage.setItem(
        STORAGE_KEYS.posActiveView,
        String(state.posActiveView || "completed")
      );

      if (state.posSelectedTransaction) {
        localStorage.setItem(
          STORAGE_KEYS.posSelectedTransaction,
          JSON.stringify(state.posSelectedTransaction)
        );
      } else {
        localStorage.removeItem(STORAGE_KEYS.posSelectedTransaction);
      }
    } catch (error) {
      console.warn("Unable to persist POS state:", error);
    }
  }

  function getInventoryItems() {
    return Array.isArray(state.inventory) ? state.inventory : [];
  }

  function getProducts() {
    return Array.isArray(state.products) ? state.products : [];
  }

  function findInventoryMatch(source = {}) {
    const inventoryItems = getInventoryItems();

    const inventoryId = String(source.inventoryId || source.itemId || "").trim();
    const sku = normalizeText(source.sku);
    const productId = normalizeText(source.productId);
    const productName = normalizeText(source.productName || source.name);

    if (inventoryId) {
      const byId = inventoryItems.find(item => String(item.id) === inventoryId);
      if (byId) return byId;
    }

    if (sku) {
      const bySku = inventoryItems.find(item => normalizeText(item.sku) === sku);
      if (bySku) return bySku;
    }

    if (productId) {
      const byProductId = inventoryItems.find(
        item => normalizeText(item.productId) === productId
      );
      if (byProductId) return byProductId;
    }

    if (productName) {
      const byName = inventoryItems.find(
        item => normalizeText(item.productName || item.name) === productName
      );
      if (byName) return byName;
    }

    return null;
  }

  function rebuildSalesFromStockHistory(existingSales = []) {
    const stockHistory = getStockHistoryRecords();

    const recoveredSales = stockHistory
      .filter(isSoldMovement)
      .map(entry => {
        const quantity = Number(entry.quantity ?? entry.quantitySold ?? entry.sold) || 0;
        const inventoryMatch = findInventoryMatch(entry);

        const cost = Number(entry.cost ?? inventoryMatch?.cost) || 0;
        const srp = Number(entry.srp ?? inventoryMatch?.srp ?? inventoryMatch?.price) || 0;

        const totalRevenue =
          Number(entry.totalRevenue ?? entry.saleAmount ?? entry.totalSaleAmount) ||
          srp * quantity;

        const totalProfit =
          Number(entry.totalProfit ?? entry.profitAmount) ||
          (srp - cost) * quantity;

        const completedTransactionId =
          entry.completedTransactionId ||
          entry.transactionId ||
          entry.completedSaleId ||
          entry.saleGroupId ||
          generateCompletedTransactionId();

        return {
          id: createRecoveredSaleId(entry),
          completedTransactionId,
          transactionId:
            entry.transactionId ||
            entry.completedTransactionId ||
            entry.completedSaleId ||
            entry.saleGroupId ||
            completedTransactionId,
          inventoryId: entry.inventoryId || entry.itemId || inventoryMatch?.id || "",
          productId: entry.productId || inventoryMatch?.productId || "",
          productName:
            entry.productName ||
            inventoryMatch?.productName ||
            inventoryMatch?.name ||
            "",
          customerName:
            entry.customerName ||
            entry.customer ||
            entry.customer_name ||
            entry.buyerName ||
            entry.clientName ||
            "-",
          customer:
            entry.customerName ||
            entry.customer ||
            entry.customer_name ||
            entry.buyerName ||
            entry.clientName ||
            "-",
          customer_name:
            entry.customerName ||
            entry.customer ||
            entry.customer_name ||
            entry.buyerName ||
            entry.clientName ||
            "-",
          buyerName:
            entry.customerName ||
            entry.customer ||
            entry.customer_name ||
            entry.buyerName ||
            entry.clientName ||
            "-",
          clientName:
            entry.customerName ||
            entry.customer ||
            entry.customer_name ||
            entry.buyerName ||
            entry.clientName ||
            "-",
          customerContact:
            normalizePHPhone(
              entry.customerContact ||
                entry.contact ||
                entry.customerPhone ||
                entry.customerEmail ||
                ""
            ) || "-",
          customerAddress: entry.customerAddress || entry.address || "-",
          invoiceNo: entry.invoiceNo || "-",
          receiptNo: entry.receiptNo || "-",
          sku: entry.sku || inventoryMatch?.sku || "",
          barcode:
            entry.barcode ||
            inventoryMatch?.barcode ||
            inventoryMatch?.barCode ||
            inventoryMatch?.bar_code ||
            inventoryMatch?.code ||
            inventoryMatch?.productId ||
            "",
          variant: entry.variant || formatAttributeLine({
            productName:
              entry.productName ||
              inventoryMatch?.productName ||
              inventoryMatch?.name,
            color: entry.color || inventoryMatch?.color,
            size: entry.size || inventoryMatch?.size,
            material: entry.material || inventoryMatch?.material,
            category: entry.category || inventoryMatch?.category
          }),
          size: entry.size || inventoryMatch?.size || "",
          color: entry.color || inventoryMatch?.color || "",
          material: entry.material || inventoryMatch?.material || "",
          category: entry.category || inventoryMatch?.category || "",
          imageData:
            entry.imageData ||
            entry.image ||
            inventoryMatch?.imageData ||
            inventoryMatch?.image ||
            "",
          image:
            entry.image ||
            entry.imageData ||
            inventoryMatch?.image ||
            inventoryMatch?.imageData ||
            "",
          quantity,
          quantitySold: quantity,
          sold: quantity,
          cost,
          srp,
          saleAmount: totalRevenue,
          totalSaleAmount: totalRevenue,
          totalRevenue,
          totalProfit,
          profitAmount: totalProfit,
          oldQty: Number(entry.oldQty ?? entry.oldQuantity) || 0,
          newQty: Number(entry.newQty ?? entry.newQuantity) || 0,
          oldQuantity: Number(entry.oldQuantity ?? entry.oldQty) || 0,
          newQuantity: Number(entry.newQuantity ?? entry.newQty) || 0,
          discount: Number(entry.discount) || 0,
          amountPaid: Number(entry.amountPaid ?? entry.paidAmount ?? 0) || 0,
          change: Number(entry.change ?? entry.changeAmount ?? 0) || 0,
          note: entry.note || "Recovered from stock history",
          status: "Completed",
          soldAt: entry.createdAt || getNowISO(),
          createdAt: entry.createdAt || getNowISO()
        };
      });

    return dedupeRecords([
      ...(Array.isArray(existingSales) ? existingSales : []),
      ...recoveredSales
    ]).sort((a, b) => {
      const aTime = new Date(a.createdAt || a.soldAt || 0).getTime();
      const bTime = new Date(b.createdAt || b.soldAt || 0).getTime();
      return bTime - aTime;
    });
  }

  function hydrateSalesFromStorage() {
    const storageSales = safeParseArray(localStorage.getItem(STORAGE_KEYS.sales));
    const storageSalesHistory = safeParseArray(localStorage.getItem(STORAGE_KEYS.salesHistory));

    const mergedSales = Array.isArray(state.sales) ? state.sales.slice() : [];
    const mergedHistory = Array.isArray(state.salesHistory) ? state.salesHistory.slice() : [];

    storageSales.forEach(item => mergedSales.push(item));
    storageSalesHistory.forEach(item => mergedHistory.push(item));

    const unifiedFromSales = dedupeRecords([
      ...mergedHistory,
      ...mergedSales
    ]).sort((a, b) => {
      const dateA = new Date(a.createdAt || a.soldAt || 0).getTime();
      const dateB = new Date(b.createdAt || b.soldAt || 0).getTime();
      return dateB - dateA;
    });

    const recoveredUnified = rebuildSalesFromStockHistory(unifiedFromSales);

    state.sales = recoveredUnified.slice();
    state.salesHistory = recoveredUnified.slice();

    persistSalesState();
  }

  function hydratePosState() {
    const storageSales = safeParseArray(localStorage.getItem(STORAGE_KEYS.sales));
    const storageSalesHistory = safeParseArray(localStorage.getItem(STORAGE_KEYS.salesHistory));

    const inMemorySales = Array.isArray(state.sales) ? state.sales : [];
    const inMemorySalesHistory = Array.isArray(state.salesHistory) ? state.salesHistory : [];

    const mergedSales = dedupeRecords([
      ...inMemorySales,
      ...inMemorySalesHistory,
      ...storageSales,
      ...storageSalesHistory
    ]).sort((a, b) => {
      const aTime = new Date(a.createdAt || a.soldAt || 0).getTime();
      const bTime = new Date(b.createdAt || b.soldAt || 0).getTime();
      return bTime - aTime;
    });

    const recoveredSales = rebuildSalesFromStockHistory(mergedSales);

    state.sales = recoveredSales.slice();
    state.salesHistory = recoveredSales.slice();

    const storedActiveView = localStorage.getItem(STORAGE_KEYS.posActiveView);
    state.posActiveView = storedActiveView || state.posActiveView || "completed";

    const storedCart = safeParseArray(localStorage.getItem(STORAGE_KEYS.posCart));

    state.posCart =
      Array.isArray(state.posCart) && state.posCart.length
        ? state.posCart
        : storedCart;

    const storedDocuments = safeParseArray(localStorage.getItem(STORAGE_KEYS.posDocuments));

    state.posDocuments =
      Array.isArray(state.posDocuments) && state.posDocuments.length
        ? state.posDocuments
        : storedDocuments;

    state.posLastPreviewDocument = state.posLastPreviewDocument || null;
    state.posCheckoutLocked = false;
    state.posDocReturnToTransaction = false;

    const storedSelectedTransaction = safeParseObject(
      localStorage.getItem(STORAGE_KEYS.posSelectedTransaction)
    );

    state.posSelectedTransaction =
      state.posSelectedTransaction || storedSelectedTransaction || null;

    persistSalesState();
    persistPosState();
  }

  function getSales() {
    
      // --- add_sale.php MySQL integration ---
      try {
        const saleForm = new FormData();
        saleForm.append("receipt_no",     receiptNo);
        saleForm.append("subtotal",       totals.subtotal);
        saleForm.append("discount",       totals.discount);
        saleForm.append("total",          totals.total);
        saleForm.append("amount_paid",    totals.paid);
        saleForm.append("change_amount",  totals.change);
        saleForm.append("note",           customer.note || "");
        saleForm.append("customer_id",    null);

        const saleRes  = await fetch("api/add_sale.php", { method: "POST", body: saleForm });
        const saleJson = await saleRes.json();
        console.log("Sale API:", saleJson);

        if (saleJson.success) {
          savedSaleId = saleJson.sale_id || null;
        }
      } catch (err) {
        console.warn("Sale API failed:", err);
      }
      // --- end add_sale.php ---

      hydrateSalesFromStorage();

      showCompletedTransactionNotification(completedTransactionId);

      showDocumentPreview(receiptDoc, {
        title: "Receipt Preview",
        returnToTransaction: false
      });

      resetCheckoutForm();

      posFilters.search = "";
      posFilters.category = "all";
      posFilters.latestOnly = true;
      posFilters.date = getDateOnly(createdAt);
      tablePagerState.completedTransactions.page = 1;

      const posSearchInput = document.getElementById("posSearchInput");
      const posCategorySort = document.getElementById("posCategorySort");
      const posDateFilter = document.getElementById("posDateFilter");

      if (posSearchInput) posSearchInput.value = "";
      if (posCategorySort) posCategorySort.value = "all";
      if (posDateFilter) posDateFilter.value = posFilters.date;

      renderProductGrid();
      renderCart();
      renderPosTable();
      switchPosView("completed");

      if (typeof refreshAll === "function") {
        setTimeout(() => {
          refreshAll();
          renderPosTable();
        }, 30);
      }

      document.dispatchEvent(new CustomEvent("racktrack:pos-updated"));
    } catch (error) {
      console.error("Checkout error:", error);

      inventoryRollback.forEach(entry => {
        const inventoryItem = getInventoryItems().find(
          item => String(item.id) === String(entry.inventoryId)
        );

        if (inventoryItem) {
          inventoryItem.quantity = entry.oldQty;
        }
      });

      if (createdSales.length) {
        const createdIds = new Set(createdSales.map(item => String(item.id)));

        state.sales = (Array.isArray(state.sales) ? state.sales : []).filter(
          item => !createdIds.has(String(item.id))
        );

        state.salesHistory = (Array.isArray(state.salesHistory) ? state.salesHistory : []).filter(
          item => !createdIds.has(String(item.id))
        );

        persistSalesState();
      }

      if (typeof saveData === "function") {
        try { saveData("inventory"); } catch (saveError) { console.warn(saveError); }
      }

      showToast(error.message || "Checkout failed.", "error");
    } finally {
      setCheckoutButtonState(false);
    }
  }

  function switchPosView(view) {
    state.posActiveView = view === "shop" ? "shop" : "completed";

    const completedView = document.getElementById("pos-completed-view");
    const shopView = document.getElementById("pos-shop-view");
    const completedBtn = document.getElementById("posCompletedTabBtn");
    const shopBtn = document.getElementById("posShopTabBtn");

    if (completedView) {
      completedView.classList.toggle("active", state.posActiveView === "completed");
    }

    if (shopView) {
      shopView.classList.toggle("active", state.posActiveView === "shop");
    }

    if (completedBtn) {
      completedBtn.classList.toggle("active", state.posActiveView === "completed");
    }

    if (shopBtn) {
      shopBtn.classList.toggle("active", state.posActiveView === "shop");
    }

    persistPosState();
    setLastActiveSection("pos-section");
  }

  function normalizeBarcodeValue(value) {
    return String(value || "").trim();
  }

  function findInventoryByBarcode(scannedCode) {
    const code = normalizeCode(scannedCode);

    if (!code) return null;

    const items = getInventoryItems();

    const byProductId = items.find(item => normalizeCode(item.productId) === code);
    if (byProductId) return byProductId;

    const byBarcode = items.find(item => {
      return [
        item.barcode,
        item.barCode,
        item.bar_code,
        item.code
      ].some(value => normalizeCode(value) === code);
    });

    if (byBarcode) return byBarcode;

    const bySku = items.find(item => normalizeCode(item.sku) === code);
    if (bySku) return bySku;

    return null;
  }

  function handleBarcodeScan(scannedCode) {
    const cleanCode = normalizeBarcodeValue(scannedCode);

    if (!cleanCode) return;

    const matchedItem = findInventoryByBarcode(cleanCode);

    if (!matchedItem) {
      showToast(`Product ID not found: ${cleanCode}`, "warning");
      return;
    }

    addToCartByInventoryId(matchedItem.id, 1);

    if ((state.posActiveView || "completed") !== "shop") {
      switchPosView("shop");
    }

    renderCart();
    renderProductGrid();

    showToast(
      `${matchedItem.productName || matchedItem.name || "Product"} added using Product ID scan.`,
      "success"
    );
  }

  function resetBarcodeBuffer() {
    BARCODE_SCAN.buffer = "";
    BARCODE_SCAN.lastTime = 0;
  }

  function isEditableTarget(target) {
    if (!target) return false;

    const id = String(target.id || "");

    if (
      id === "posSearchInput" ||
      id === "posShopSearchInput"
    ) {
      return false;
    }

    const tagName = String(target.tagName || "").toLowerCase();

    return (
      tagName === "input" ||
      tagName === "textarea" ||
      tagName === "select" ||
      !!target.isContentEditable
    );
  }

  function bindBarcodeScannerEvents() {
    if (document.body && document.body.dataset.barcodeScannerBound === "true") return;

    if (document.body) {
      document.body.dataset.barcodeScannerBound = "true";
    }

    document.addEventListener("keydown", function (event) {
      if (!BARCODE_SCAN.enabled) return;

      const activeElement = document.activeElement;

      if (isEditableTarget(activeElement)) return;

      const key = event.key || "";
      const now = Date.now();
      const gap = now - BARCODE_SCAN.lastTime;

      if (gap > BARCODE_SCAN.timeoutMs) {
        BARCODE_SCAN.buffer = "";
      }

      BARCODE_SCAN.lastTime = now;

      if (key === "Enter") {
        const scanned = BARCODE_SCAN.buffer.trim();
        resetBarcodeBuffer();

        if (scanned.length >= BARCODE_SCAN.minLength) {
          event.preventDefault();
          handleBarcodeScan(scanned);
        }

        return;
      }

      if (
        key === "Shift" ||
        key === "Control" ||
        key === "Alt" ||
        key === "Meta" ||
        key === "CapsLock" ||
        key === "Tab"
      ) {
        return;
      }

      if (key === "Backspace") {
        BARCODE_SCAN.buffer = BARCODE_SCAN.buffer.slice(0, -1);
        return;
      }

      if (key.length === 1) {
        BARCODE_SCAN.buffer += key;
      }
    });
  }

  function bindProductGridEvents() {
    const grid = document.getElementById("posProductGrid");

    if (!grid || grid.dataset.bound === "true") return;

    grid.dataset.bound = "true";

    grid.addEventListener("click", function (event) {
      const addBtn = event.target.closest("[data-add-cart]");

      if (!addBtn) return;

      const inventoryId = addBtn.getAttribute("data-add-cart") || "";

      if (!inventoryId) return;

      let qtyInput = null;

      try {
        qtyInput = grid.querySelector(
          `.pos-card-qty-input[data-inventory-id="${CSS.escape(inventoryId)}"]`
        );
      } catch (error) {
        qtyInput = grid.querySelector(
          `.pos-card-qty-input[data-inventory-id="${inventoryId}"]`
        );
      }

      const qty = Number(qtyInput?.value) || 1;

      addToCartByInventoryId(inventoryId, qty);
    });
  }

  function bindCartEvents() {
    const cartWrap = document.getElementById("posCartItems");

    if (!cartWrap || cartWrap.dataset.bound === "true") return;

    cartWrap.dataset.bound = "true";

    cartWrap.addEventListener("click", function (event) {
      const minusBtn = event.target.closest("[data-cart-minus]");

      if (minusBtn) {
        const id = minusBtn.getAttribute("data-cart-minus") || "";
        const item = getCartItems().find(entry => String(entry.inventoryId) === String(id));
        updateCartQty(id, (Number(item?.quantity) || 1) - 1);
        return;
      }

      const plusBtn = event.target.closest("[data-cart-plus]");

      if (plusBtn) {
        const id = plusBtn.getAttribute("data-cart-plus") || "";
        const item = getCartItems().find(entry => String(entry.inventoryId) === String(id));
        updateCartQty(id, (Number(item?.quantity) || 1) + 1);
        return;
      }

      const removeBtn = event.target.closest("[data-cart-remove]");

      if (removeBtn) {
        const id = removeBtn.getAttribute("data-cart-remove") || "";
        removeCartItem(id);
      }
    });

    cartWrap.addEventListener("input", function (event) {
      const qtyInput = event.target.closest("[data-cart-qty]");

      if (!qtyInput) return;

      const id = qtyInput.getAttribute("data-cart-qty") || "";

      updateCartQty(id, qtyInput.value);
    });
  }

  function bindCompletedTableEvents() {
    const tbody = document.getElementById("posTableBody");

    if (!tbody || tbody.dataset.bound === "true") return;

    tbody.dataset.bound = "true";

    tbody.addEventListener("click", function (event) {
      const row = event.target.closest("tr.pos-clickable-row");

      if (!row) return;

      const transactionKey = row.getAttribute("data-transaction-key") || "";
      const transaction = buildCompletedTransactionRows().find(
        item => item.key === transactionKey
      );

      if (!transaction) {
        showToast("Transaction details not found.", "warning");
        return;
      }

      openTransactionModalBySale(transaction);
    });
  }

  function bindCompletedPaginationEvents() {
    const wrap = ensureCompletedPaginationWrap();

    if (!wrap || wrap.dataset.bound === "true") return;

    wrap.dataset.bound = "true";

    wrap.addEventListener("click", function (event) {
      const btn = event.target.closest("[data-page]");

      if (!btn || btn.disabled) return;

      const nextPage = Number(btn.getAttribute("data-page")) || 1;

      tablePagerState.completedTransactions.page = nextPage;
      renderPosTable();
    });
  }

  function bindTransactionModalEvents() {
    const overlay = document.getElementById("posTransactionModalOverlay");
    const closeBtn = document.getElementById("posTransactionCloseBtn");
    const closeFooterBtn = document.getElementById("posTransactionCloseFooterBtn");
    const quotationBtn = document.getElementById("posTransactionQuotationBtn");
    const invoiceBtn = document.getElementById("posTransactionInvoiceBtn");
    const receiptBtn = document.getElementById("posTransactionReceiptBtn");

    if (overlay && !overlay.dataset.bound) {
      overlay.dataset.bound = "true";

      overlay.addEventListener("click", function (event) {
        if (event.target === overlay) {
          event.stopPropagation();
        }
      });
    }

    if (closeBtn && !closeBtn.dataset.bound) {
      closeBtn.dataset.bound = "true";
      closeBtn.addEventListener("click", closeTransactionModal);
    }

    if (closeFooterBtn && !closeFooterBtn.dataset.bound) {
      closeFooterBtn.dataset.bound = "true";
      closeFooterBtn.addEventListener("click", closeTransactionModal);
    }

    if (quotationBtn && !quotationBtn.dataset.bound) {
      quotationBtn.dataset.bound = "true";
      quotationBtn.addEventListener("click", function () {
        openSavedTransactionDocument("quotation");
      });
    }

    if (invoiceBtn && !invoiceBtn.dataset.bound) {
      invoiceBtn.dataset.bound = "true";
      invoiceBtn.addEventListener("click", function () {
        openSavedTransactionDocument("invoice");
      });
    }

    if (receiptBtn && !receiptBtn.dataset.bound) {
      receiptBtn.dataset.bound = "true";
      receiptBtn.addEventListener("click", function () {
        openSavedTransactionDocument("receipt");
      });
    }
  }

  function bindDocModalEvents() {
    const overlay = document.getElementById("posDocModalOverlay");
    const closeBtn = document.getElementById("posDocCloseBtn");
    const closeFooterBtn = document.getElementById("posDocCloseFooterBtn");

    if (overlay && !overlay.dataset.bound) {
      overlay.dataset.bound = "true";

      overlay.addEventListener("click", function (event) {
        if (event.target === overlay) {
          event.stopPropagation();
        }
      });
    }

    if (closeBtn && !closeBtn.dataset.bound) {
      closeBtn.dataset.bound = "true";
      closeBtn.addEventListener("click", closeDocModal);
    }

    if (closeFooterBtn && !closeFooterBtn.dataset.bound) {
      closeFooterBtn.dataset.bound = "true";
      closeFooterBtn.addEventListener("click", closeDocModal);
    }
  }

  function bindEvents() {
    const completedBtn = document.getElementById("posCompletedTabBtn");

    if (completedBtn && !completedBtn.dataset.bound) {
      completedBtn.dataset.bound = "true";

      completedBtn.addEventListener("click", function () {
        switchPosView("completed");
      });
    }

    const shopBtn = document.getElementById("posShopTabBtn");

    if (shopBtn && !shopBtn.dataset.bound) {
      shopBtn.dataset.bound = "true";

      shopBtn.addEventListener("click", function () {
        switchPosView("shop");
      });
    }

    const posSearchInput = document.getElementById("posSearchInput");

    if (posSearchInput && !posSearchInput.dataset.bound) {
      posSearchInput.dataset.bound = "true";

      posSearchInput.addEventListener("input", function () {
        posFilters.search = this.value || "";
        tablePagerState.completedTransactions.page = 1;
        renderPosTable();
      });
    }

    const posCategorySort = document.getElementById("posCategorySort");

    if (posCategorySort && !posCategorySort.dataset.bound) {
      posCategorySort.dataset.bound = "true";

      posCategorySort.addEventListener("change", function () {
        posFilters.category = this.value || "all";
        tablePagerState.completedTransactions.page = 1;
        renderPosTable();
      });
    }

    const posDateFilter = document.getElementById("posDateFilter");

    if (posDateFilter && !posDateFilter.dataset.bound) {
      posDateFilter.dataset.bound = "true";

      posDateFilter.addEventListener("change", function () {
        posFilters.date = this.value || "";
        posFilters.latestOnly = false;
        tablePagerState.completedTransactions.page = 1;
        renderPosTable();
      });
    }

    const posLatestBtn = document.getElementById("posLatestBtn");

    if (posLatestBtn && !posLatestBtn.dataset.bound) {
      posLatestBtn.dataset.bound = "true";

      posLatestBtn.addEventListener("click", function () {
        posFilters.latestOnly = true;
        tablePagerState.completedTransactions.page = 1;
        renderPosTable();
      });
    }

    const posShopSearchInput = document.getElementById("posShopSearchInput");

    if (posShopSearchInput && !posShopSearchInput.dataset.bound) {
      posShopSearchInput.dataset.bound = "true";

      posShopSearchInput.addEventListener("input", function () {
        shopFilters.search = this.value || "";
        renderProductGrid();
      });
    }

    const posShopCategorySort = document.getElementById("posShopCategorySort");

    if (posShopCategorySort && !posShopCategorySort.dataset.bound) {
      posShopCategorySort.dataset.bound = "true";

      posShopCategorySort.addEventListener("change", function () {
        shopFilters.category = this.value || "all";
        renderProductGrid();
      });
    }

    const clearCartBtn = document.getElementById("posClearCartBtn");

    if (clearCartBtn && !clearCartBtn.dataset.bound) {
      clearCartBtn.dataset.bound = "true";

      clearCartBtn.addEventListener("click", function () {
        clearCart();
      });
    }

    const discountInput = document.getElementById("posCartDiscount");
    const paidInput = document.getElementById("posCartPaid");

    if (discountInput && !discountInput.dataset.bound) {
      discountInput.dataset.bound = "true";

      discountInput.addEventListener("input", function () {
        renderCart();
        persistPosState();
      });
    }

    if (paidInput && !paidInput.dataset.bound) {
      paidInput.dataset.bound = "true";

      paidInput.addEventListener("input", function () {
        renderCart();
        persistPosState();
      });
    }

    const customerNameInput =
      document.getElementById(
        "posCartCustomerName"
      );

    if (
      customerNameInput &&
      !customerNameInput.dataset.bound
    ) {
      customerNameInput.dataset.bound = "true";

      customerNameInput.addEventListener(
        "input",
        function () {
          updateCustomerNameStyle();
          persistPosState();
        }
      );
    }

    const customerContactInput = document.getElementById("posCartCustomerContact");

    if (customerContactInput && !customerContactInput.dataset.phoneBound) {
      customerContactInput.dataset.phoneBound = "true";
      customerContactInput.placeholder = "+63 9XX XXX XXXX";
      customerContactInput.inputMode = "tel";

      customerContactInput.addEventListener("input", function () {
        this.value = normalizePHPhone(this.value);
        persistPosState();
      });

      customerContactInput.addEventListener("blur", function () {
        const formatted = normalizePHPhone(this.value);
        this.value = formatted;

        if (formatted && !isValidPHPhone(formatted)) {
          showToast("Phone number must be in this format: +63 9XX XXX XXXX.", "warning");
        }

        persistPosState();
      });
    }

    const quotationBtn = document.getElementById("posPreviewQuoteBtn");

    if (quotationBtn && !quotationBtn.dataset.bound) {
      quotationBtn.dataset.bound = "true";

      quotationBtn.addEventListener("click", function () {
        openDocumentPreview("quotation");
      });
    }

    const invoiceBtn = document.getElementById("posPreviewInvoiceBtn");

    if (invoiceBtn && !invoiceBtn.dataset.bound) {
      invoiceBtn.dataset.bound = "true";

      invoiceBtn.addEventListener("click", function () {
        openDocumentPreview("invoice");
      });
    }

    const checkoutBtn = document.getElementById("posCheckoutBtn");

    if (checkoutBtn && !checkoutBtn.dataset.bound) {
      checkoutBtn.dataset.bound = "true";

      checkoutBtn.addEventListener("click", function () {
        checkoutCart();
      });
    }

    bindProductGridEvents();
    bindCartEvents();
    bindCompletedTableEvents();
    bindCompletedPaginationEvents();
    bindTransactionModalEvents();
    bindDocModalEvents();
    bindBarcodeScannerEvents();
  }

  function initCompletedTransactionDefaults() {
    const rows = buildCompletedTransactionRows();
    const latestDate = getLatestTransactionDate(rows);

    if (!posFilters.date && latestDate) {
      posFilters.date = latestDate;
    }

    posFilters.latestOnly = true;
  }

  function renderPanel() {
    hydratePosState();

    state.sales = Array.isArray(state.sales) ? state.sales : [];
    state.salesHistory = Array.isArray(state.salesHistory) ? state.salesHistory : [];
    state.posCart = Array.isArray(state.posCart) ? state.posCart : [];

    initCompletedTransactionDefaults();
    renderPosTable();
    renderProductGrid();
    renderCart();

    updateCustomerNameStyle(); // ADD THIS

    bindEvents();
    switchPosView(state.posActiveView || "completed");
    setCheckoutButtonState(false);
    setLastActiveSection("pos-section");
  }

  window.RackTrackPOS = {
    showToast,
    showCompletedTransactionNotification,
    getSales,
    getInventoryItems,
    getProducts,
    findInventoryMatch,
    findInventoryByBarcode,
    handleBarcodeScan,
    normalizeSaleRecord,
    renderPanel,
    renderPosTable,
    formatPeso,
    formatDateTime,
    formatAttributeLine,
    switchPosView,
    renderProductGrid,
    renderCart,
    checkoutCart,
    openDocumentPreview,
    openTransactionModalBySale,
    closeTransactionModal,
    buildTransactionSummary,
    buildCompletedTransactionRows,
    openSavedTransactionDocument,
    closeDocModal,
    reopenTransactionModal,
    printDocument,
    generateCompletedTransactionId,
    normalizePHPhone,
    isValidPHPhone
  };

  if (typeof registerPanel === "function") {
    registerPanel({
      id: "pos-section",
      render: renderPanel
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    hydratePosState();
    renderPanel();
  });
})();
