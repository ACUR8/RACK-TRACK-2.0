<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include "config.php";

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => false,
        "message" => "Only POST requests are allowed"
    ]);
    exit;
}

// Read POST form data
$category_name = isset($_POST["category_name"])
    ? trim($_POST["category_name"])
    : "";

$category_color = isset($_POST["category_color"])
    ? trim($_POST["category_color"])
    : "#f2b14c";

// Validation
if (empty($category_name)) {
    echo json_encode([
        "success" => false,
        "message" => "Category name is required"
    ]);
    exit;
}

// Check duplicate (case-insensitive)
$checkSql = "
SELECT category_id
FROM categories
WHERE LOWER(category_name) = LOWER(?)
";

$checkStmt = $conn->prepare($checkSql);

if (!$checkStmt) {
    echo json_encode([
        "success" => false,
        "message" => "Failed to add category"
    ]);
    exit;
}

$checkStmt->bind_param("s", $category_name);
$checkStmt->execute();

$result = $checkStmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "message" => "Category already exists"
    ]);

    $checkStmt->close();
    exit;
}

$checkStmt->close();

// Insert category
$sql = "
INSERT INTO categories (
    category_name,
    category_color
)
VALUES (?, ?)
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Failed to add category"
    ]);
    exit;
}

$stmt->bind_param(
    "ss",
    $category_name,
    $category_color
);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Category added successfully"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to add category"
    ]);
}

$stmt->close();
$conn->close();

?>