<?php
include "config.php";

$data = $_POST;

$product_id = $data["product_id"] ?? null;
$barcode = $data["barcode"] ?? null;
$sku = $data["sku"] ?? null;
$supplier = $data["supplier"] ?? null;
$product_name = $data["product_name"] ?? null;
$color = $data["color"] ?? null;
$size = $data["size"] ?? null;
$material = $data["material"] ?? null;
$category_id = $data["category"] ?? null;
$cost = $data["cost"] ?? 0;
$srp = $data["srp"] ?? 0;

if (!$product_id) {
  echo json_encode(["success" => false, "message" => "Product ID is required for update"]);
  exit;
}

// Get existing image_path before updating
$existingImagePath = null;
$selectSql = "SELECT image_path FROM products WHERE product_id = ?";
$selectStmt = $conn->prepare($selectSql);
if (!$selectStmt) {
  echo json_encode(["success" => false, "message" => "Database error: " . $conn->error]);
  exit;
}

$selectStmt->bind_param("s", $product_id);
$selectStmt->execute();
$selectResult = $selectStmt->get_result();
$existingRow = $selectResult->fetch_assoc();

if (!$existingRow) {
  echo json_encode(["success" => false, "message" => "Product not found"]);
  exit;
}

$existingImagePath = $existingRow["image_path"];
$selectStmt->close();

// Handle image file upload
$image_path = $existingImagePath; // Default to existing path

if (!empty($_FILES["productImage"])) {
  $file = $_FILES["productImage"];
  
  // Validate file
  $allowed_types = ["image/jpeg", "image/png", "image/gif", "image/webp"];
  $max_size = 5 * 1024 * 1024; // 5MB
  
  if ($file["error"] !== UPLOAD_ERR_OK) {
    echo json_encode(["success" => false, "message" => "File upload error: " . $file["error"]]);
    exit;
  }
  
  if (!in_array($file["type"], $allowed_types)) {
    echo json_encode(["success" => false, "message" => "Invalid file type. Only JPEG, PNG, GIF, and WebP are allowed."]);
    exit;
  }
  
  if ($file["size"] > $max_size) {
    echo json_encode(["success" => false, "message" => "File size exceeds 5MB limit."]);
    exit;
  }
  
  // Get file extension
  $ext_map = [
    "image/jpeg" => "jpg",
    "image/png" => "png",
    "image/gif" => "gif",
    "image/webp" => "webp"
  ];
  $extension = $ext_map[$file["type"]] ?? "jpg";
  
  // Create upload directory
  $upload_dir = "../assets/images/products/";
  if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
  }
  
  // Generate unique filename
  $unique_name = "product_" . time() . "_" . uniqid() . "." . $extension;
  $upload_path = $upload_dir . $unique_name;
  
  // Move uploaded file
  if (!move_uploaded_file($file["tmp_name"], $upload_path)) {
    echo json_encode(["success" => false, "message" => "Failed to save image file"]);
    exit;
  }
  
  // Delete old image file if it exists and is different
  if ($existingImagePath && $existingImagePath !== $unique_name) {
    $old_file_path = "../" . $existingImagePath;
    if (file_exists($old_file_path)) {
      @unlink($old_file_path);
    }
  }
  
  // Store relative path in database
  $image_path = "assets/images/products/" . $unique_name;
}

$sql = "UPDATE products 
SET 
  barcode = ?,
  sku = ?,
  supplier = ?,
  product_name = ?,
  color = ?,
  size = ?,
  material = ?,
  category_id = ?,
  cost = ?,
  srp = ?,
  image_path = ?,
  updated_at = NOW()
WHERE product_id = ?";

$stmt = $conn->prepare($sql);

$stmt->bind_param(
  "sssssssiidss",
  $barcode,
  $sku,
  $supplier,
  $product_name,
  $color,
  $size,
  $material,
  $category_id,
  $cost,
  $srp,
  $image_path,
  $product_id
);

if ($stmt->execute()) {
  echo json_encode(["success" => true, "message" => "Product updated successfully"]);
} else {
  echo json_encode(["success" => false, "message" => $stmt->error]);
}
$stmt->close();
?>
