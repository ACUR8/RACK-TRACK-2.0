<?php
include "config.php";

$data = $_POST;

$barcode = $data["barcode"];
$sku = $data["sku"];
$supplier = $data["supplier"];
$product_name = $data["product_name"];
$color = $data["color"];
$size = $data["size"];
$material = $data["material"];
$category_id = $data["category"];
$cost = $data["cost"];
$srp = $data["srp"];
$status = "active";
$image_path = null;

// Handle file upload
if (!empty($_FILES["productImage"])) {
  $file = $_FILES["productImage"];
  
  // Validate file
  $allowed_types = ["image/jpeg", "image/png", "image/gif", "image/webp"];
  $max_size = 5 * 1024 * 1024; // 5MB
  
  if (!in_array($file["type"], $allowed_types)) {
    echo json_encode(["success" => false, "message" => "Invalid file type. Only JPEG, PNG, GIF, and WebP are allowed."]);
    exit;
  }
  
  if ($file["size"] > $max_size) {
    echo json_encode(["success" => false, "message" => "File size exceeds 5MB limit."]);
    exit;
  }
  
  if ($file["error"] !== UPLOAD_ERR_OK) {
    echo json_encode(["success" => false, "message" => "File upload error."]);
    exit;
  }
  
  // Create directory if it doesn't exist
  $upload_dir = "../assets/images/products/";
  if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
  }
  
  // Generate unique filename
  $extension = pathinfo($file["name"], PATHINFO_EXTENSION);
  $unique_name = "product_" . time() . "_" . uniqid() . "." . $extension;
  $upload_path = $upload_dir . $unique_name;
  
  // Move uploaded file
  if (move_uploaded_file($file["tmp_name"], $upload_path)) {
    $image_path = "assets/images/products/" . $unique_name;
  } else {
    echo json_encode(["success" => false, "message" => "Failed to save image file."]);
    exit;
  }
}

$sql = "INSERT INTO products 
(barcode, sku, supplier, product_name, color, size, material, category_id, cost, srp, image_path, status)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

$stmt->bind_param(
  "sssssssidsss",
  $barcode,
  $sku,
  $supplier,
  $product_name,
  $color,
  $size,
  $material,
  $category_id,
  $cost,
  $srp,
  $image_path,
  $status
);

if ($stmt->execute()) {
  echo json_encode(["success" => true, "message" => "Product added successfully"]);
} else {
  echo json_encode(["success" => false, "message" => $stmt->error]);
}
?>
