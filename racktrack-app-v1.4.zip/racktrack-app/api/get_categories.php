<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include "config.php";

$sql = "
SELECT 
    category_id,
    category_name,
    category_color
FROM categories
ORDER BY category_name ASC
";

$result = $conn->query($sql);

if (!$result) {
    die(json_encode(["error" => $conn->error]));
}

$categories = [];

while ($row = $result->fetch_assoc()) {
    $categories[] = $row;
}

echo json_encode($categories);
?>