<?php
include "config.php";

echo "RackTrack database connected successfully.";
?>