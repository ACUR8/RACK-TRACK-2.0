<?php
include "config.php";

$data = $_POST;

$product_id = $data["product_id"] ?? null;

if (!$product_id) {
  echo json_encode(["success" => false, "message" => "Product ID is required for deletion"]);
  exit;
}

$sql = "DELETE FROM products WHERE product_id = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
  echo json_encode(["success" => false, "message" => "Database error: " . $conn->error]);
  exit;
}

$stmt->bind_param("s", $product_id);

if ($stmt->execute()) {
  if ($stmt->affected_rows > 0) {
    echo json_encode(["success" => true, "message" => "Product deleted successfully."]);
  } else {
    echo json_encode(["success" => false, "message" => "Product not found."]);
  }
} else {
  echo json_encode(["success" => false, "message" => "Failed to delete product: " . $stmt->error]);
}

$stmt->close();
?>
