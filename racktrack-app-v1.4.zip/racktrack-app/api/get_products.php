<?php
include "config.php";

$sql = "
SELECT 
    p.*,
    c.category_name,
    c.category_color
FROM products p
LEFT JOIN categories c
ON p.category_id = c.category_id
";

$result = $conn->query($sql);

$products = [];

while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

header("Content-Type: application/json");
echo json_encode($products);
?>