<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include "config.php";

// Extract POST parameters
$receipt_no = trim($_POST["receipt_no"] ?? "");
$customer_id = isset($_POST["customer_id"]) && $_POST["customer_id"] !== ""
    ? (int)$_POST["customer_id"]
    : null;
$subtotal = (float)($_POST["subtotal"] ?? 0);
$discount = (float)($_POST["discount"] ?? 0);
$total = (float)($_POST["total"] ?? 0);
$amount_paid = (float)($_POST["amount_paid"] ?? 0);
$change_amount = (float)($_POST["change_amount"] ?? 0);
$note = trim($_POST["note"] ?? "");
$payment_method = $_POST["payment_method"] ?? "cash";
$sale_status = $_POST["sale_status"] ?? "completed";

$cashier_id = 1;

// Validate required fields
if (
    !$receipt_no ||
    $subtotal < 0 ||
    $discount < 0 ||
    $total < 0 ||
    $amount_paid < 0 ||
    $change_amount < 0
) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid receipt_no or numeric values"
    ]);
    exit;
}

// Insert sale
$sql = "INSERT INTO sales (
    receipt_no,
    customer_id,
    cashier_id,
    subtotal,
    discount,
    total,
    amount_paid,
    change_amount,
    note,
    payment_method,
    sale_status
)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Prepare failed: " . $conn->error
    ]);
    exit;
}

$stmt->bind_param(
    "siidddddsss",
    $receipt_no,
    $customer_id,
    $cashier_id,
    $subtotal,
    $discount,
    $total,
    $amount_paid,
    $change_amount,
    $note,
    $payment_method,
    $sale_status
);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Sale saved successfully",
        "sale_id" => $conn->insert_id
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to save sale: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
?>
